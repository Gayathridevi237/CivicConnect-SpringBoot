# 📝 SpringBlog Project

This is a simple blog platform built with **Spring Boot** and **Thymeleaf**, offering user authentication, post and comment management, and role-based access control.

## 🚀 Features

### 🛠 User Management

* **Registration & Login** with Spring Security
* Role-based access: *USER*, *ADMIN*

### 📝 Blog Posts

* Create, read, update, and delete posts
* Rich text editing support (e.g., Markdown)
* Post listing with pagination

### 💬 Comments

* Add, edit, and delete comments on posts
* Nested comment threads

### 🔒 Security

* Authentication & authorization using Spring Security
* Session-based login with cookies

### 🌐 Thymeleaf UI

* Server-side rendered views for posts, comments, and user profiles
* Responsive design using Bootstrap or Tailwind CSS

## 🛠 Technologies

* **Spring Boot**
* **Spring Data JPA**
* **Spring Security**
* **Thymeleaf**
* **JUnit & Mockito** for testing

## 🚦 Getting Started

Clone the repository and run the project locally:

```
git clone https://github.com/Pololac/SpringBlog.git
cd SpringBlog
./mvnw spring-boot:run
```

### Prerequisites

* Java 17 or higher

* Maven 3.6 or higher

* MySQL (running on port 8889 on my MAMP)

1. **Configure Environment Properties**

Create an env.properties file at the root of the project (outside of src/) and define your database credentials:

```
env.properties
spring.datasource.username=YOUR_DB_USERNAME
spring.datasource.password=YOUR_DB_PASSWORD
```

Update src/main/resources/application.properties to load these values:

```
spring.datasource.url=jdbc:mysql://localhost:8889/hb_cda_java_springblog
spring.datasource.username=${spring.datasource.username}
spring.datasource.password=${spring.datasource.password}

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

(Optional) If you use Spring profiles (e.g., dev, prod), repeat these settings in application-{profile}.properties.

2. **Seed the Database with Sample Posts**

A SQL dump of the post table has been provided to quickly populate your database with five sample articles.

Ensure the data/ directory exists at the project root (it contains posts-data.sql):
```
ls data/posts-data.sql
```

Create the database if it doesn’t already exist:

```
mysql -u${spring.datasource.username} -p${spring.datasource.password} \
-e "CREATE DATABASE IF NOT EXISTS hb_cda_java_springblog;"
```

Import the sample data:

```
mysql -u${spring.datasource.username} -p${spring.datasource.password} \
hb_cda_java_springblog < data/posts-data.sql
```

Restart the application; you should now see five sample posts in your database.

3. **Build and Run**
```
# Compile and package the application
dot mvn clean package

# Run the JAR
java -jar target/SpringBlog-0.0.1-SNAPSHOT.jar
```

Open your browser at http://localhost:8080 to view the blog.

### Project Structure

* src/main/java – Application source code

* src/main/resources – Spring configuration and templates

* data/ – SQL seed files for sample data


## 🤝 Contributing

Contributions, bug reports, and feature requests are welcome!

* Open an issue
* Submit a pull request
