package com.hb.cda.springblog.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.hb.cda.springblog.controller.dto.UserRegisterDTO;
import com.hb.cda.springblog.entity.User;
import com.hb.cda.springblog.repository.UserRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
@Transactional
public class AuthController {
    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }


    @GetMapping("/register")
    public String displayRegister(Model model) {
        model.addAttribute("userDto", new UserRegisterDTO());
        
        return "register-form";
    }

    @PostMapping("/register")
    public String processRegister(@Valid @ModelAttribute("userDto") UserRegisterDTO userDto, BindingResult bindingResult, Model model) {
        // Vérification si l'utilisateur existe déjà en BDD
        if (userRepo.findByUsername(userDto.getUsername()).isPresent()) {
            bindingResult.addError(new FieldError("userDto", "username", "User already exists"));
        }

        // Vérification si les deux mots de passe correspondent
        if (!userDto.getPassword().equals(userDto.getRepeatPassword())) {
            bindingResult.addError(new FieldError("userDto", "repeatPassword", "Passwords don't match"));
            return "register-form";
        }
        
        // Gestion des erreurs de validation
        if(bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getFieldErrors());
            return "register-form";
        }

        User user = new User();
        user.setUsername(userDto.getUsername());
        String hashedPassword = passwordEncoder.encode(userDto.getPassword());
        user.setPassword(hashedPassword);
        user.setRole("ROLE_USER"); // On attribue le rôle par défaut

        userRepo.save(user);
        model.addAttribute("success", "User registered successfully");

        return "redirect:/login";
    }

    @GetMapping("login")
    public String displayLogin() {
        return "login-form";
    }
}
