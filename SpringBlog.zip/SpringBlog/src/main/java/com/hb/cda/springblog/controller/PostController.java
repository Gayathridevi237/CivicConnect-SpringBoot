package com.hb.cda.springblog.controller;


import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import com.hb.cda.springblog.controller.dto.AddPostDTO;
import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.Reaction;
import com.hb.cda.springblog.entity.User;
import com.hb.cda.springblog.repository.PostRepository;
import com.hb.cda.springblog.repository.ReactionRepository;
import com.hb.cda.springblog.repository.UserRepository;
import org.springframework.web.bind.annotation.RequestBody;



@Controller
@Transactional
public class PostController {

    private PostRepository postRepo;
    private UserRepository userRepo;
    private ReactionRepository reactRepo;

    public PostController(PostRepository postRepo, UserRepository userRepo, ReactionRepository reactRepo) {
        this.postRepo = postRepo;
        this.userRepo = userRepo;
        this.reactRepo = reactRepo;
    }

    @GetMapping("/add-post")
    public String getPostForm(Model model) {
        model.addAttribute("addPostDTO", new AddPostDTO());
        return "post-form";
    }
    
    @PostMapping("/add-post")
    public String addPost(@Valid AddPostDTO addPostDTO, BindingResult bindingResult, Model model, @AuthenticationPrincipal User user) {
        // Gestion des erreurs de validation
        if(bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getFieldErrors());
            return "post-form";
        }

        Post post = new Post();
        post.setTitle(addPostDTO.getTitle());
        post.setContent(addPostDTO.getContent());
        post.setAuthor(user);
        post.setPostedAt(LocalDateTime.now());

        postRepo.save(post);
        
        return "redirect:/posts";
    }

    @GetMapping("/posts")
    public String listPosts(
            @RequestParam(name = "page", defaultValue = "1") int pageNumber,
            Model model) {
        Pageable pageable = PageRequest.of(pageNumber - 1, 5, Sort.by("postedAt").descending());
        Page<Post> postsPage = postRepo.findAll(pageable);
        model.addAttribute("posts", postsPage.getContent());
        model.addAttribute("totalPages", postsPage.getTotalPages());
        model.addAttribute("currentPage", pageNumber);
        return "posts";
    }

    @GetMapping("/author/{id}")
    public String getAuthorPosts(
            @PathVariable String id,
            @RequestParam(name = "page", defaultValue = "1") int pageNumber,
            Model model) {
        Pageable pageable = PageRequest.of(pageNumber - 1, 5, Sort.by("postedAt").ascending());
        
        Optional<User> authorOpt = userRepo.findById(id);
        if(authorOpt.isPresent()) {
            User author = authorOpt.get();
            Page<Post> postsPage = postRepo.findByAuthor(author, pageable);
            model.addAttribute("posts", postsPage.getContent());
            model.addAttribute("totalPages", postsPage.getTotalPages());
            model.addAttribute("currentPage", pageNumber);
        } else {
            return "author_not_found";
        }
        return "posts";
    }

    @GetMapping("/post/{id}")
    public String getPost(@PathVariable String id, @AuthenticationPrincipal User user, Model model) {
        model.addAttribute("user", user);
        Optional<Post> postOpt = postRepo.findById(id);

        if(postOpt.isPresent()) {
            Post post = postOpt.get();
            model.addAttribute("post", post);
            model.addAttribute("reactionCounts", post.getReactionsCountByType());
        } else {
            return "404";
        }

        return "post";
    }

    @PostMapping("/post/{id}")
    public String addReaction(
        @PathVariable String id, 
        @RequestParam(name = "type") String emoji,
        @AuthenticationPrincipal User user,
        Model model) {
        
        Optional<Post> postOpt = postRepo.findById(id);
        if(postOpt.isEmpty()) return "404";

        Post post = postOpt.get();

        // 1. Chercher s'il y a déjà une réaction de ce user sur ce post
        Optional<Reaction> existingReaction = reactRepo.findByUserAndPost(user, post);

        // 2. MODIFIER la réaction existante, SINON créer une nouvelle réaction
        Reaction reaction = reactRepo.findByUserAndPost(user, post).orElse(
            new Reaction(user, post));

        if (reaction.getType() != null && reaction.getType().equals(emoji)) {
            reactRepo.delete(reaction);
        } else {
            reaction.setType(emoji);
            reactRepo.save(reaction);
        }

        // Mettre à jour nbr de réactions par type
        Map<String, Integer> reactionCounts = post.getReactionsCountByType();
        model.addAttribute("reactionCounts", reactionCounts);
    
        model.addAttribute("post", post);
        model.addAttribute("user", user);

        return "redirect:/post/" + id;  // Appelle le GET et réinitialise le modèle.
    }

    @PostMapping("/post/delete/{id}")
    public String deletePost(@PathVariable String id, @AuthenticationPrincipal User user) {
        Post post = postRepo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Post does not exist"));
        if(!post.getAuthor().equals(user)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You don't have the rights to delete this post");
        }
        postRepo.delete(post);
        return "redirect:/author/"+user.getUsername();
    }

}
