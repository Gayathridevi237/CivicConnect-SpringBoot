package com.hb.cda.springblog.entity;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String title;
    @Lob // Large Object, used for large text content
    private String content;
    private LocalDateTime postedAt;
    
    @ManyToOne
    private User author;
    
    @OneToMany(mappedBy = "post", orphanRemoval = true)
    private List<Reaction> reactions = new ArrayList<>();
    
    public Post() {
    }
    
    public Post(String title, String content, LocalDateTime postedAt) {
        this.title = title;
        this.content = content;
        this.postedAt = postedAt;
    }

    public Post(String id, String title, String content, LocalDateTime postedAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.postedAt = postedAt;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    
    public LocalDateTime getPostedAt() {
        return postedAt;
    }
    public void setPostedAt(LocalDateTime postedAt) {
        this.postedAt = postedAt;
    }
    
    public User getAuthor() {
        return author;
    }
    public void setAuthor(User author) {
        this.author = author;
    }
    
    public List<Reaction> getReactions() {
        return reactions;
    }
    public void setReactions(List<Reaction> reactions) {
        this.reactions = reactions;
    }
    
    public void addReaction(Reaction reaction) {
        if (!reactions.contains(reaction)) {
            reaction.setPost(this);
            reactions.add(reaction);
        }
    }
    public void removeReaction(Reaction reaction) {
        this.reactions.remove(reaction);
        reaction.setPost(null);
    }

    public String getPostedSince(Clock clock) {
        LocalDateTime now = LocalDateTime.now(clock);
        Duration duration = Duration.between(postedAt, now);
        long seconds = duration.getSeconds();

        // 1) SECONDES
        if (seconds < 60) {
            return format(seconds, "seconde");
        }

        // 2) MINUTES
        long minutes = seconds / 60;
        if (minutes < 60) {
            return format(minutes, "minute");
        }

        // 3) HEURES
        long hours = minutes / 60;
        if (hours < 24) {
            return format(hours, "heure");
        }

        // 4) JOURS (jusqu'à 30 journées)
        long days = hours / 24;
        if (days <= 30) {
            return format(days, "jour");
        }

        // c) Tous les autres cas : on retourne la date brute
        return postedAt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    private String format(long value, String unit) {
        // gère le pluriel
        return "il y a " + value + " " + unit + (value > 1 ? "s" : "");
    }

    public String getPostedSince() {
        return getPostedSince(Clock.systemDefaultZone());
    }
    
    // AFFICHAGE NBR REACTIONS SUR LE POST
    public Map<String, Integer> getReactionsCountByType(){
        Map<String, Integer> reactionMap = new HashMap();
        if (this.getReactions() != null) {
            for (Reaction reaction : this.getReactions()) {
                String emoji = reaction.getType();
                reactionMap.put(emoji, reactionMap.getOrDefault(emoji,  0) + 1);
            }
        }
        return reactionMap;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    //Nécessaire pour que comparer les posts par leur id
    //Si on ne le fait pas, on compare les objets par leur référence mémoire
    //Ce qui n'est pas ce qu'on veut dans ce cas
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Post other = (Post) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
    
}
