package com.hb.cda.springblog.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.User;

@Repository
public interface PostRepository extends JpaRepository<Post, String> {
    // Pour configurer le nombre de posts par page
    Page<Post> findByAuthor(User author, Pageable pageable);

    //Soit l'un, soit l'autre, pour faire en sorte d'aller chercher les post avec leur author directement en une seule requête
    // @Query("FROM Post p LEFT JOIN FETCH p.author")
    @EntityGraph(attributePaths = {"author"})
    Page<Post> findAll(Pageable pageable);

    
}
