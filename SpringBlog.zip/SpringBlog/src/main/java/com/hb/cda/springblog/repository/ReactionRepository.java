package com.hb.cda.springblog.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.entity.Reaction;
import com.hb.cda.springblog.entity.User;

@Repository
public interface ReactionRepository extends JpaRepository<Reaction, String> {
    Optional<Reaction> findByUserAndPost(User user, Post post);
}
