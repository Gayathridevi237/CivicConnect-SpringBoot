package com.hb.cda.springblog;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.hb.cda.springblog.entity.Post;
import com.hb.cda.springblog.repository.PostRepository;

import jakarta.transaction.Transactional;

@SpringBootTest
@AutoConfigureTestDatabase
@AutoConfigureMockMvc
@Transactional
class AddPostFunctionalTest {
    @Autowired
    MockMvc mvc;
    @Autowired
    PostRepository postRepo;

    @Test
    @WithMockUser()
    void shouldPersistPostIfLogged() throws Exception {
        mvc.perform(MockMvcRequestBuilders.post("/add-post")
        .with(SecurityMockMvcRequestPostProcessors.csrf())
        .formField("title", "test title")
        .formField("content", "test content"))
        .andExpect(MockMvcResultMatchers.status().isFound());

        assertTrue(
            postRepo.findOne(Example.of(new Post("test title", "test content", any()))
        ).isPresent());
    }
    @Test
    void shouldNotPersistPostIfNotLogged() throws Exception {
        mvc.perform(MockMvcRequestBuilders.post("/add-post")
        .with(SecurityMockMvcRequestPostProcessors.csrf())
        .formField("title", "test title")
        .formField("content", "test content"))
        .andExpect(MockMvcResultMatchers.status().isFound())
        .andExpect(MockMvcResultMatchers.redirectedUrl("http://localhost/login"));

        assertTrue(
            postRepo.findOne(Example.of(new Post("test title", "test content", any()))
        ).isEmpty());
    }
}
