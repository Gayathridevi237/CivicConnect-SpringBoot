package com.hb.cda.springblog.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;


class PostTest {
    
    @ParameterizedTest
    @MethodSource("fixtures")
    void getPostedSince_ShouldReturnExpectedResult(LocalDateTime postedAt, String expected) {
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime fixedNow = LocalDateTime.of(2024, 1, 1, 0, 0, 0);
        Clock clock = Clock.fixed(fixedNow.atZone(zone).toInstant(), zone);

        Post post = new Post("id", "title", postedAt);
        assertEquals(expected, post.getPostedSince(clock));
    }


    // Méthode de données pour les tests
    static Stream<Arguments> fixtures() {
        LocalDateTime now = LocalDateTime.of(2024, 1, 1, 0, 0, 0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    
        return Stream.of(
            // Secondes (< 60)
            Arguments.of(now.minusSeconds(1), "il y a 1 seconde"),
            Arguments.of(now.minusSeconds(23), "il y a 23 secondes"),
            // Minutes (< 60)
            Arguments.of(now.minusMinutes(1), "il y a 1 minute"),
            Arguments.of(now.minusMinutes(16), "il y a 16 minutes"),
            // Heures (< 24)
            Arguments.of(now.minusHours(1), "il y a 1 heure"),
            Arguments.of(now.minusHours(20), "il y a 20 heures"),
            // Jours [1, 30]
            Arguments.of(now.minusDays(1), "il y a 1 jour"),
            Arguments.of(now.minusDays(3), "il y a 3 jours"),
            Arguments.of(now.minusDays(30), "il y a 30 jours"),
            // Supérieur à 30 jours -> date formatée brute
            Arguments.of(now.minusDays(32), now.minusDays(32).format(fmt)),
            Arguments.of(now.minusMonths(13), now.minusMonths(13).format(fmt))
        );
    }
}
