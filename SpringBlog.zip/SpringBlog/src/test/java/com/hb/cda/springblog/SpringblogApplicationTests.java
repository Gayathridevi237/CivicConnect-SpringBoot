package com.hb.cda.springblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
