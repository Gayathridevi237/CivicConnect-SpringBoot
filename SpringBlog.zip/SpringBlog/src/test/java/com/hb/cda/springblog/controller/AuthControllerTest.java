package com.hb.cda.springblog.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.assertArg;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.hb.cda.springblog.controller.dto.UserRegisterDTO;
import com.hb.cda.springblog.entity.User;
import com.hb.cda.springblog.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {
    @Mock
    PasswordEncoder encoder;
    @Mock
    UserRepository repo;
    @Mock 
    Model model;
    @Mock
    BindingResult bindingResult;
    @InjectMocks
    AuthController authController;

    @Test
    void registerShouldHashPasswordAndAssignRole() {
        when(encoder.encode(anyString())).thenReturn("hash");
        String result = authController.processRegister(
            new UserRegisterDTO("test", "1234", "1234"), 
            bindingResult, 
            model);

        verify(repo, times(1)).save(assertArg(user -> {
            assertEquals("test", user.getUsername());
            assertEquals("hash", user.getPassword());
            assertEquals("ROLE_USER", user.getRole());
        }));
        assertEquals("redirect:/login", result);
    }

    
    @Test
    void registerShouldNotPersistIfPasswordDontMatch() {
        String result = authController.processRegister(
            new UserRegisterDTO("test", "1234", "4321"), 
            bindingResult, 
            model);

        verify(repo, never()).save(any());
        verify(bindingResult, times(1)).addError(any());
        assertEquals("register-form", result);
    }

    @Test
    void registerShouldNotPersistIfUserExists() {
        when(bindingResult.hasErrors()).thenReturn(true);
        when(repo.findByUsername("test")).thenReturn(Optional.of(new User()));
        String result = authController.processRegister(
            new UserRegisterDTO("test", "1234", "1234"), 
            bindingResult, 
            model);

        verify(repo, never()).save(any());
        verify(bindingResult, times(1)).addError(any());
        assertEquals("register-form", result);
    }
}

