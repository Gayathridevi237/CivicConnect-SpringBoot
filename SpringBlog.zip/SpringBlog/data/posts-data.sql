-- MySQL dump 10.13  Distrib 8.0.40, for macos12.7 (arm64)
--
-- Host: localhost    Database: hb_cda_java_springblog
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`id`, `content`, `posted_at`, `title`, `author_id`) VALUES ('048ae4ac-5b6e-4e40-9802-4f0f5ee1bfc0','Les assistants vocaux, intégrés dans nos smartphones et enceintes connectées, révolutionnent notre interaction avec la technologie. Grâce à l’IA et au traitement du langage naturel, ils comprennent nos requêtes, gèrent notre agenda et pilotent les objets connectés, rendant le quotidien plus fluide.','2025-08-01 09:39:33.775441','L’essor des assistants vocaux','c0b5f421-3f5f-4303-bbdd-d74512bbf09b'),('7628335e-5b26-435b-8a24-b9cbb74744eb','Le développement rapide de l’IA soulève des enjeux éthiques : biais algorithmiques, transparence des décisions et respect de la vie privée. Les entreprises et législateurs doivent collaborer pour établir des normes garantissant une IA fiable et respectueuse des droits fondamentaux de chaque utilisateur.','2025-08-01 09:40:40.785367','L’intelligence artificielle éthique','c0b5f421-3f5f-4303-bbdd-d74512bbf09b'),('85f3b44e-dd29-4edc-a467-c4c0abd89c3e','Alors que les objets connectés se multiplient dans nos foyers, la question de la sécurité devient cruciale. Failles logicielles, authentification faible et absence de mises à jour exposent nos données personnelles. Il est essentiel de choisir des équipements labellisés et de maintenir leurs firmwares à jour.','2025-08-01 09:40:11.479821','Sécurité des objets connectés','c0b5f421-3f5f-4303-bbdd-d74512bbf09b'),('9bb3bfd6-a44a-4b1b-84d1-83306f01b8ab','Le cloud hybride combine datacenters privés et services cloud publics, offrant flexibilité et sécurité. Les entreprises gagnent en agilité pour monter en charge tout en gardant le contrôle de leurs données sensibles. Cette stratégie permet d’optimiser coûts et performances selon les besoins opérationnels.','2025-08-01 09:40:54.809145','Le cloud hybride pour les entreprises','c0b5f421-3f5f-4303-bbdd-d74512bbf09b'),('ed37d12a-9286-4197-9dc8-9c80035df08f','La 5G promet des débits ultra-rapides et une latence quasi nulle, ouvrant la voie à la réalité augmentée, aux véhicules autonomes et à l’IoT industriel. Les villes intelligentes et la téléchirurgie à distance deviendront réalité, transformant profondément les secteurs de la santé, de l’industrie et des transports.','2025-08-01 09:41:10.395294','La 5G et ses usages futurs','c0b5f421-3f5f-4303-bbdd-d74512bbf09b');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-01 12:00:20
